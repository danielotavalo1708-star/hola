"""
Servidor del chat WebSocket para subir a internet (sin ventana).

- Entrega la página web (chat_web.html) y atiende los WebSocket por el mismo puerto.
- Lee el puerto de la variable de entorno PORT (así lo piden Render, Railway, etc.).
- Límite por archivo con la variable MAX_MB (por defecto 25 MB).

Ejecutar en tu PC para probar:   python servidor_nube.py
"""
import asyncio
import json
import os
import struct
from http import HTTPStatus

import websockets
from websockets.asyncio.server import serve, broadcast

PUERTO = int(os.environ.get("PORT", "8765"))
MAX_BYTES = int(float(os.environ.get("MAX_MB", "25")) * 1024 * 1024)
RUTA_PAGINA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "chat_web.html")

clientes = {}   # conexión -> nombre de usuario


def aviso_sistema(texto):
    return json.dumps({"tipo": "sistema", "texto": texto})


def enviar_a_otros(origen, dato):
    broadcast([c for c in clientes if c is not origen], dato)


def leer_cabecera(dato):
    try:
        largo = struct.unpack(">I", dato[:4])[0]
        return json.loads(dato[4:4 + largo].decode("utf-8"))
    except Exception:
        return {}


def servir_pagina(connection, request):
    """Si piden una página normal (no WebSocket), responde con chat_web.html."""
    if request.headers.get("Upgrade", "").lower() == "websocket":
        return None

    ruta = request.path.split("?")[0]
    if ruta not in ("/", "/index.html"):
        return connection.respond(HTTPStatus.NOT_FOUND, "No encontrado\n")

    try:
        with open(RUTA_PAGINA, "r", encoding="utf-8") as f:
            html = f.read()
    except OSError:
        return connection.respond(
            HTTPStatus.NOT_FOUND, "Falta chat_web.html junto a servidor_nube.py\n"
        )

    html = html.replace(
        "<!--SERVIDOR_PROPIO-->",
        '<meta name="servidor-propio" content="1">'
        f'<meta name="limite-bytes" content="{MAX_BYTES}">',
    )
    respuesta = connection.respond(HTTPStatus.OK, html)
    if "Content-Type" in respuesta.headers:
        del respuesta.headers["Content-Type"]
    respuesta.headers["Content-Type"] = "text/html; charset=utf-8"
    return respuesta


async def manejar_cliente(websocket):
    clientes[websocket] = "Anónimo"
    try:
        async for dato in websocket:
            nombre = clientes.get(websocket, "Anónimo")

            if isinstance(dato, str):
                try:
                    msg = json.loads(dato)
                except json.JSONDecodeError:
                    continue

                if msg.get("tipo") == "hola":
                    nombre = str(msg.get("usuario", "Anónimo"))[:30]
                    clientes[websocket] = nombre
                    print(f"[+] {nombre} se conectó (total: {len(clientes)})", flush=True)
                    enviar_a_otros(websocket, aviso_sistema(f"{nombre} se conectó"))
                    continue

                print(f"[{nombre}] {msg.get('texto', '')}", flush=True)
            else:
                cab = leer_cabecera(dato)
                print(f"[{nombre}] archivo: {cab.get('nombre', '?')} "
                      f"({len(dato) / 1024:.0f} KB)", flush=True)

            enviar_a_otros(websocket, dato)
    except websockets.ConnectionClosed:
        pass
    finally:
        nombre = clientes.pop(websocket, "Anónimo")
        print(f"[-] {nombre} se desconectó (total: {len(clientes)})", flush=True)
        enviar_a_otros(websocket, aviso_sistema(f"{nombre} se desconectó"))


async def main():
    async with serve(
        manejar_cliente,
        "0.0.0.0",
        PUERTO,
        process_request=servir_pagina,
        max_size=MAX_BYTES + 1_000_000,
        ping_interval=20,    # mantiene viva la conexión detrás de proxys en la nube
        ping_timeout=60,
    ):
        print(f"Servidor listo en el puerto {PUERTO} (archivos de hasta "
              f"{MAX_BYTES // (1024 * 1024)} MB)", flush=True)
        await asyncio.Future()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nServidor detenido.")
